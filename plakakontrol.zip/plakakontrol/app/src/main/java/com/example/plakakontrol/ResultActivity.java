package com.example.plakakontrol;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView txtMesaj = findViewById(R.id.txtMesaj);
        Button btnGeri = findViewById(R.id.btnGeri);

        String mesaj = getIntent().getStringExtra("mesaj");
        if (mesaj != null) {
            txtMesaj.setText(mesaj);
        }

        btnGeri.setOnClickListener(v -> finish());
    }
}

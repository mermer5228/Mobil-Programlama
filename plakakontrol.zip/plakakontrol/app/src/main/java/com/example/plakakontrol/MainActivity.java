package com.example.plakakontrol; 

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    String[] iller = {"Adana", "Adıyaman", "Afyon", "Ağrı", "Amasya", "Ankara", "Antalya", "Artvin", "Aydın", "Balıkesir", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa", "Çanakkale", "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Edirne", "Elazığ", "Erzincan", "Erzurum", "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Isparta", "Mersin", "İstanbul", "İzmir", "Kars", "Kastamonu", "Kayseri", "Kırklareli", "Kırşehir", "Kocaeli", "Konya", "Kütahya", "Malatya", "Manisa", "K.Maraş", "Mardin", "Muğla", "Muş", "Nevşehir", "Niğde", "Ordu", "Rize", "Sakarya", "Samsun", "Siirt", "Sinop", "Sivas", "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Şanlıurfa", "Uşak", "Van", "Yozgat", "Zonguldak", "Aksaray", "Bayburt", "Karaman", "Kırıkkale", "Batman", "Şırnak", "Bartın", "Ardahan", "Iğdır", "Yalova", "Karabük", "Kilis", "Osmaniye", "Düzce"};

    ArrayList<Integer> plakaListesi = new ArrayList<>();
    ArrayList<String> sehirListesi = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listPlakaUI = findViewById(R.id.listPlakalar);
        ListView listSehirUI = findViewById(R.id.listSehirler);
        Button btnUret = findViewById(R.id.btnUret);

        listeleriHazirla(listPlakaUI, listSehirUI);

        btnUret.setOnClickListener(v -> listeleriHazirla(listPlakaUI, listSehirUI));

        listPlakaUI.setOnItemClickListener((parent, view, position, id) -> {
            int secilenPlaka = plakaListesi.get(position);
            String karsiSehir = sehirListesi.get(position);

            int gercekPlaka = Arrays.asList(iller).indexOf(karsiSehir) + 1;

            if (secilenPlaka == gercekPlaka) {
                Toast.makeText(this, "DOĞRU: " + karsiSehir + " - " + secilenPlaka, Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                intent.putExtra("mesaj", karsiSehir + " ile eşleşmedi");
                startActivity(intent);
            }
        });
    }

    void listeleriHazirla(ListView l1, ListView l2) {
        plakaListesi.clear();
        sehirListesi.clear();

        for (int i = 1; i <= 81; i++) {
            plakaListesi.add(i);
        }
        sehirListesi.addAll(Arrays.asList(iller));

        Collections.shuffle(plakaListesi);
        Collections.shuffle(sehirListesi);

        l1.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, plakaListesi));
        l2.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, sehirListesi));
    }
}
